#!/usr/bin/env bash
#Here is an example, the parameters here can be modified as you see fit.
export N=100
export THRESHOLD=0.5
export INPUT1=input1
export INPUT2=input2
export OUTPUT=output
export OUTPUT_MULTITHREAD=output-multithread

