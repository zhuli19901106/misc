#!/usr/bin/env bash
cd solution-using-only-python
./cleanup.sh
cd ..

cd solution-using-hadoop
./cleanup.sh
cd ..

cd solution-using-spark
./cleanup.sh
cd ..

