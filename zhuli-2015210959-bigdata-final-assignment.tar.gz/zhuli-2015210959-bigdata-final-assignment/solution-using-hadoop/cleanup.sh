#!/usr/bin/env bash
source ./env.sh
rm -rf $INPUT1 $INPUT2 $INPUT_WLN1 $INPUT_WLN2 $PAIRS $OUTPUT

