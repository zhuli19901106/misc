#!/usr/bin/env bash
#Here is an example, the parameters here can be modified as you see fit.
export N=100
export THRESHOLD=0.5
export INPUT1=input1
export INPUT_WLN1=input-wln1
export INPUT2=input2
export INPUT_WLN2=input-wln2
export PAIRS=pairs
export OUTPUT=output

