#!/usr/bin/env bash
#Here is an example, the parameters here can be modified as you see fit.
source ./env.sh

echo "Running spark example:"
time ./run-an-example.sh

