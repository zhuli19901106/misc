大数据分析与内存计算 期末作业

姓名：朱里
专业：2015级计算机系硕士
学号：2015210959
导师：舒继武教授

写在最前面：运行run-me.sh就能看到结果。前提是你装了spark。

请先阅读上层的README文件。

运行须知：
1. cleanup.sh 清除输出文件。
2. run-me.sh 运行python示例，所有内容输出log中。
3. README.txt 你正在看。

相关文件如下：
1. env.sh 用到的一些shell脚本变量在此定义，可以修改。
2. generate-random-dataset.py 生成随机的数据集，参数可以指定。
3. run-an-example.sh 示例脚本。
6. jaccard-similarity.py pyspark的脚本。

在Spark版本耗时一个钟头。剩下的时间用来写这些README以及整理文件。
